﻿using System;
using System.Security.Cryptography; // Для SHA (заглушка)
using System.Text; // Для StringBuilder, Encoding
using System.Threading; // Для Thread
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents; // Для Paragraph, Run у RichTextBox
using System.Windows.Media; // Для Brushes, Color
using System.Windows.Shapes; // Для Rectangle, Ellipse
using System.Windows.Threading; // Для Dispatcher

namespace Lab10_MultithreadingCryptoWPF
{
    /// <summary>
    /// Логіка взаємодії для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // CancellationTokenSource для кожного потоку для керування скасуванням
        private CancellationTokenSource cts1;
        private CancellationTokenSource cts2;
        private CancellationTokenSource cts3;

        // Об'єкти потоків
        private Thread thread1;
        private Thread thread2;
        private Thread thread3;

        private Random random = new Random(); // Генератор випадкових чисел

        // Лічильники для керування очищенням Canvas
        private int drawCount1 = 0;
        private int drawCount2 = 0;
        private const int MaxShapesBeforeClear = 50; // Очищати Canvas кожні N фігур

        public MainWindow()
        {
            InitializeComponent();
            // Ініціалізуємо CancellationTokenSource та потоки при запуску
            InitializeAllThreadsAndCts();
            // Прив'язуємо обробник події закриття вікна
            this.Closing += MainWindow_Closing;
        }

        /// <summary>
        /// Ініціалізує всі CancellationTokenSource та потоки.
        /// Цей метод викликається при запуску програми та при повторному запуску потоків,
        /// якщо вони вже були завершені.
        /// </summary>
        private void InitializeAllThreadsAndCts()
        {
            // Створюємо нові CancellationTokenSource
            cts1 = new CancellationTokenSource();
            cts2 = new CancellationTokenSource();
            cts3 = new CancellationTokenSource();

            // Створюємо нові потоки, передаючи їм методи для виконання та CancellationToken
            // Важливо: лямбда-вираз захоплює значення cts1 (об'єкт), а не посилання на нього.
            thread1 = new Thread(() => Method1_REDOC_Rectangles(cts1.Token)) { IsBackground = true };
            thread2 = new Thread(() => Method2_SHA_Ellipses(cts2.Token)) { IsBackground = true };
            thread3 = new Thread(() => Method3_LUC_GenerateNumbers(cts3.Token)) { IsBackground = true };
        }

        /// <summary>
        /// Запускає або повторно ініціалізує та запускає потік, якщо він неактивний.
        /// </summary>
        /// <param name="threadRef">Посилання на об'єкт потоку.</param>
        /// <param name="ctsRef">Посилання на об'єкт CancellationTokenSource для потоку.</param>
        /// <param name="threadMethod">Метод, який виконуватиме потік.</param>
        private void StartThreadSafe(ref Thread threadRef, ref CancellationTokenSource ctsRef, Action<CancellationToken> threadMethod)
        {
            // Якщо потік неіснуючий, завершений або припинений, створюємо новий
            if (threadRef == null || !threadRef.IsAlive || threadRef.ThreadState == ThreadState.Stopped || threadRef.ThreadState == ThreadState.Aborted)
            {
                ctsRef = new CancellationTokenSource(); // Створюємо новий CTS
                // Важливо: захоплюємо значення ctsRef у локальну змінну, щоб уникнути CS1628
                CancellationTokenSource currentCts = ctsRef;
                threadRef = new Thread(() => threadMethod(currentCts.Token)) { IsBackground = true };
                threadRef.Start();
            }
        }

        // === Метод 1: REDOC (заглушка) - візуалізація через малювання прямокутників ===
        /// <summary>
        /// Симулює роботу алгоритму REDOC шляхом безперервного малювання прямокутників на canvas1.
        /// </summary>
        /// <param name="cancellationToken">Токен для скасування виконання потоку.</param>
        private void Method1_REDOC_Rectangles(CancellationToken cancellationToken)
        {
            drawCount1 = 0; // Скидаємо лічильник при запуску потоку
            while (!cancellationToken.IsCancellationRequested) // Перевіряємо, чи не було запиту на скасування
            {
                try
                {
                    Dispatcher.Invoke(() => // Використовуємо Dispatcher.Invoke для безпечного доступу до UI
                    {
                        if (drawCount1 >= MaxShapesBeforeClear)
                        {
                            canvas1.Children.Clear(); // Очищаємо Canvas
                            drawCount1 = 0;
                        }

                        // Створюємо прямокутник з випадковими розмірами та кольором
                        Rectangle rect = new Rectangle
                        {
                            Width = random.Next(20, (int)canvas1.ActualWidth / 2),
                            Height = random.Next(20, (int)canvas1.ActualHeight / 2),
                            Fill = new SolidColorBrush(Color.FromArgb(200, (byte)random.Next(256), (byte)random.Next(256), (byte)random.Next(256))), // Випадковий напівпрозорий колір
                            Stroke = Brushes.Black,
                            StrokeThickness = 1
                        };
                        // Встановлюємо випадкову позицію
                        Canvas.SetLeft(rect, random.Next((int)canvas1.ActualWidth - (int)rect.Width));
                        Canvas.SetTop(rect, random.Next((int)canvas1.ActualHeight - (int)rect.Height));
                        canvas1.Children.Add(rect); // Додаємо прямокутник на Canvas
                        drawCount1++;
                    }, DispatcherPriority.Background); // Запускаємо з низьким пріоритетом, щоб не блокувати UI
                    Thread.Sleep(40); // Затримка для візуалізації
                }
                catch (OperationCanceledException)
                {
                    // Обробка скасування
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Помилка у Method1_REDOC_Rectangles: {ex.Message}");
                    break;
                }
            }
            // Очищаємо Canvas після зупинки потоку
            Dispatcher.Invoke(() => canvas1.Children.Clear());
        }


        // === Метод 2: SHA (заглушка) - візуалізація через малювання еліпсів ===
        /// <summary>
        /// Симулює роботу алгоритму SHA шляхом безперервного малювання еліпсів на canvas2.
        /// </summary>
        /// <param name="cancellationToken">Токен для скасування виконання потоку.</param>
        private void Method2_SHA_Ellipses(CancellationToken cancellationToken)
        {
            drawCount2 = 0; // Скидаємо лічильник при запуску потоку
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    Dispatcher.Invoke(() =>
                    {
                        if (drawCount2 >= MaxShapesBeforeClear)
                        {
                            canvas2.Children.Clear(); // Очищаємо Canvas
                            drawCount2 = 0;
                        }

                        Ellipse ellipse = new Ellipse
                        {
                            Width = random.Next(20, (int)canvas2.ActualWidth / 2),
                            Height = random.Next(20, (int)canvas2.ActualHeight / 2),
                            Fill = new SolidColorBrush(Color.FromArgb(200, (byte)random.Next(256), (byte)random.Next(256), (byte)random.Next(256))), // Випадковий напівпрозорий колір
                            Stroke = Brushes.Black,
                            StrokeThickness = 1
                        };
                        Canvas.SetLeft(ellipse, random.Next((int)canvas2.ActualWidth - (int)ellipse.Width));
                        Canvas.SetTop(ellipse, random.Next((int)canvas2.ActualHeight - (int)ellipse.Height));
                        canvas2.Children.Add(ellipse);
                        drawCount2++;
                    }, DispatcherPriority.Background);
                    Thread.Sleep(40); // Затримка
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Помилка у Method2_SHA_Ellipses: {ex.Message}");
                    break;
                }
            }
            // Очищаємо Canvas після зупинки потоку
            Dispatcher.Invoke(() => canvas2.Children.Clear());
        }

        // === Метод 3: LUC (заглушка) - генерація чисел/символів ===
        /// <summary>
        /// Симулює роботу алгоритму LUC або генератора випадкових чисел
        /// шляхом безперервної генерації та виводу випадкових чисел у RichTextBox.
        /// </summary>
        /// <param name="cancellationToken">Токен для скасування виконання потоку.</param>
        private void Method3_LUC_GenerateNumbers(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    Dispatcher.Invoke(() =>
                    {
                        // Перевіряємо, чи RichTextBox ще не вивантажений або видалений
                        if (!richTextBox1.IsLoaded) return;

                        // Генеруємо випадкове число та додаємо його до RichTextBox
                        richTextBox1.AppendText(random.Next(1000).ToString() + " ");
                        // Прокручуємо до кінця, щоб бачити нові значення
                        richTextBox1.ScrollToEnd();

                        // Обмеження розміру тексту для уникнення переповнення
                        if (richTextBox1.Document.Blocks.Count > 500)
                        {
                            richTextBox1.Document.Blocks.Remove(richTextBox1.Document.Blocks.FirstBlock);
                        }
                    }, DispatcherPriority.Background);
                    Thread.Sleep(100); // Затримка для візуалізації
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Помилка у Method3_LUC_GenerateNumbers: {ex.Message}");
                    break;
                }
            }
            // Очищаємо RichTextBox після зупинки потоку
            Dispatcher.Invoke(() => richTextBox1.Document.Blocks.Clear());
        }

        // === Обробники подій кнопок ===

        private void btnStart1_Click(object sender, RoutedEventArgs e)
        {
            StartThreadSafe(ref thread1, ref cts1, Method1_REDOC_Rectangles);
        }

        private void btnStop1_Click(object sender, RoutedEventArgs e)
        {
            cts1?.Cancel(); // Відправляємо сигнал на скасування
        }

        private void btnStart2_Click(object sender, RoutedEventArgs e)
        {
            StartThreadSafe(ref thread2, ref cts2, Method2_SHA_Ellipses);
        }

        private void btnStop2_Click(object sender, RoutedEventArgs e)
        {
            cts2?.Cancel();
        }

        private void btnStart3_Click(object sender, RoutedEventArgs e)
        {
            StartThreadSafe(ref thread3, ref cts3, Method3_LUC_GenerateNumbers);
        }

        private void btnStop3_Click(object sender, RoutedEventArgs e)
        {
            cts3?.Cancel();
        }

        private void btnStartAll_Click(object sender, RoutedEventArgs e)
        {
            // Спочатку скасовуємо всі існуючі потоки, якщо вони працюють
            btnStopAll_Click(sender, e);
            Thread.Sleep(200); // Даємо час потокам на завершення

            // Запускаємо всі потоки заново
            StartThreadSafe(ref thread1, ref cts1, Method1_REDOC_Rectangles);
            StartThreadSafe(ref thread2, ref cts2, Method2_SHA_Ellipses);
            StartThreadSafe(ref thread3, ref cts3, Method3_LUC_GenerateNumbers);
        }

        private void btnStopAll_Click(object sender, RoutedEventArgs e)
        {
            cts1?.Cancel();
            cts2?.Cancel();
            cts3?.Cancel();
        }

        /// <summary>
        /// Обробник події закриття головного вікна.
        /// Важливо: Завершуємо всі потоки, коли вікно закривається.
        /// </summary>
        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Надсилаємо сигнал скасування всім потокам
            cts1?.Cancel();
            cts2?.Cancel();
            cts3?.Cancel();

            // Чекаємо на завершення потоків.
            // Уникаємо блокування UI-потоку, якщо потоки довго завершуються.
            // Завдяки CancellationToken, потоки мають завершитися коректно.
            // Timeout в Join є хорошою практикою.
            thread1?.Join(200);
            thread2?.Join(200);
            thread3?.Join(200);

            // Очищаємо ресурси CancellationTokenSource
            cts1?.Dispose();
            cts2?.Dispose();
            cts3?.Dispose();
        }
    }
}
